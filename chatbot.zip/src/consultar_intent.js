const dialogflow = require("dialogflow");
const uuid = require("uuid");
const sessionId = uuid.v4();

module.exports = {
  buscar_intent: async function (projectId, msg) {
  // Create a new session
    const sessionClient = new dialogflow.SessionsClient();
    const sessionPath = sessionClient.sessionPath(projectId, sessionId);
    // La solicitud de consulta de texto.
    const request = {
      session: sessionPath,
      queryInput: {
        text: {
          // La consulta para enviar al agente de dialogflow
          text: msg,
          // El lenguaje utilizado por el cliente.
          languageCode: "es",
        },
      }, // Fin queryInput:
    }; // Fin const request
    const responses = await sessionClient.detectIntent(request);
    const result = responses[0].queryResult;
    const fulfillmentTextReply = result.fulfillmentText;

    return result['fulfillmentText'];
  } // Fin of this function: async function
}//Fin exports
